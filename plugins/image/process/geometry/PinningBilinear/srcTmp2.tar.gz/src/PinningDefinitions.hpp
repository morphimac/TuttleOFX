#ifndef _TUTTLE_PLUGIN_PINNING_DEFINITIONS_HPP_
#define _TUTTLE_PLUGIN_PINNING_DEFINITIONS_HPP_

#include <tuttle/common/utils/global.hpp>


namespace tuttle {
namespace plugin {
namespace pinning {

const std::string kClipOptionalSourceRef( "SourceRef" );

const static std::string kParamPointSource = "pointSrc";	//param point de depart
const static std::string kParamPointDestination = "pointDst";	//param point arrive
const static std::string kParamGroupSource = "groupSrc";	//groupe points depart
const static std::string kParamGroupDestination = "groupDst";	//groupe points arrivee

const static std::string kParamHelpButton = "Help";		//param bouton aide
const static std::string kParamHelpString = "<b>Pinning</b> plugin is used to ???.  <br />";

const static std::string kParamDisplayOptions = "displayOptions";	//Groupe affichage
const static std::string kParamGridOverlay = "gridOverlay";

const std::string kParamGridCenter( "gridCenter" );
const std::string kParamGridCenterOverlay( "gridCenterOverlay" );
const std::string kParamCenter( "center" );
const std::string kParamCenterOverlay( "pinningCenterOverlay" );

const std::string kParamDebugDisplayRoi( "debugDisplayRoi" );

//const std::string kParamDisplaySource( "displaySource" );	//param afficher grille


}
}
}

#endif
