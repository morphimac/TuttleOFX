#ifndef _TUTTLE_PLUGIN_PINNING_PLUGIN_HPP_
#define _TUTTLE_PLUGIN_PINNING_PLUGIN_HPP_

#include <tuttle/common/utils/global.hpp>
#include <ofxsImageEffect.h>
#include <boost/gil/gil_all.hpp>

namespace tuttle {
namespace plugin {
namespace pinning {

template<typename Scalar>
struct PinningProcessParams
{
	
};

/**
 * @brief Pinning plugin
 */
class PinningPlugin : public OFX::ImageEffect
{
public:
	typedef float Scalar;
public:
    PinningPlugin( OfxImageEffectHandle handle );

public:
	PinningProcessParams<Scalar> getProcessParams( const OfxPointD& renderScale = OFX::kNoRenderScale ) const;

	void changedParam( const OFX::InstanceChangedArgs &args, const std::string &paramName );

	bool isIdentity( const OFX::RenderArguments& args, OFX::Clip*& identityClip, double& identityTime );

	void render( const OFX::RenderArguments &args );
	
	
public:
	// do not need to delete these, the ImageEffect is managing them for us
	OFX::Clip* _clipSrc; ///< Source image clip
	OFX::Clip* _clipDst; ///< Destination image clip
	OFX::Clip* _srcRefClip; ///< source ref image clip

	OFX::GroupParam* _groupDisplayParams; ///< groupe des options d'affichage
	OFX::BooleanParam*  _gridOverlay; ///< grid overlay
	OFX::Double2DParam* _gridCenter; ///< grid center
	OFX::BooleanParam*  _gridCenterOverlay; ///< grid center overlay
	OFX::Double2DParam* _center; ///< center coordonnates
	OFX::BooleanParam*  _centerOverlay; ///< lens center overlay

	OFX::BooleanParam* _debugDisplayRoi; ///< debug display options

	OFX::Double2DParam* _paramSrc[4];
	OFX::Double2DParam* _paramDst[4];

	///@{
	/// can't use static because it's common to all plugin instances...
	/// so it's not perfect but it's just here for debug purpose (used in overlay)
	static OfxRectD _dstRoi;
	static OfxRectD _srcRoi;
	static OfxRectD _srcRealRoi;
	///@}
};

}
}
}

#endif
